#!/bin/bash
./build/app/main -c 0xe --log-level=7 -- -p 0xf
#./build/app/main -c 0xe --log-level=7 -- -p 0xe

